<?php
	$config = array(
		'tittle' => 'Расписание',
		'db' => array(
			'server' => 'localhost',
			'username' => 'root',
			'password' => 'pass',
			'name' => 'tt'
		)
	);
?>