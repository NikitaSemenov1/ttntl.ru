fout = open("settings.txt", "w")

fout.write("keklol")

fout.close()
